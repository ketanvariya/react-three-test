import * as THREE from 'three';
// import { acceleratedRaycast, computeBoundsTree, disposeBoundsTree } from 'three-mesh-bvh';
import React, { Component } from 'react'
import { ThreeViewer } from '../commonFunctions/ThreeViewer.js';
import HomeView, { ImageToSvgConverter } from './homeView.jsx'
import { shapeViewer } from '../views/shapeViewer.js';


export default class Home extends Component {
    componentDidMount() {
        console.log("called three.js logic")
        // initiate three here
        let threeViewer = new ThreeViewer({
            element: document.getElementById('container3D')
        })

        threeViewer.initViewer()
        // shapeLoader()
        shapeViewer(threeViewer)
        window.threeViewer = threeViewer


        // customImageLoader(threeViewer.scene)
    }
    render() {
        return (
            <div>
                <HomeView />
                {/* <ImageToSvgConverter /> */}
            </div>
        )
    }
}


